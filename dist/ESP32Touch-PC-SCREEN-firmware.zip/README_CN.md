# ESP32 Touch Dashboard 完整固件 — 2026-11-01

适用 ESP32-D0WD-V3 / 4 MB Flash / ILI9341 320×240 + XPT2046。
目标是 esp32，不能用于 ESP32-S3。请保留工程原接线。

包含原有监控、PC SCREEN、五款游戏、完整月薪猫与周五颜色修复，
以及独立 Codex／Claude 模型名称显示。配套 EXE 版本 2026.11.01.2。

先暂停 Dashboard 并关闭串口工具，在本目录核对 SHA256SUMS.txt 后执行：

    python -m esptool --chip esp32 --port COM5 --baud 460800 --before default_reset --after hard_reset write_flash "@flash_args"

将 COM5 改为实际端口。写入 bootloader 0x1000、分区表 0x8000、应用 0x10000。
不要整片擦除；保留 NVS 中的 Wi-Fi、校准、来源和薪资设置。包内不含 NVS 或个人 Flash 备份。

烧录后恢复新版 Dashboard；设备主页 CODEX／CLAUDE 切换模型名称与合计金额。
OTHER → SALARY CAT 打开月薪猫，SYSTEM → PC SCREEN 查看所选 PC 窗口。
计费由本机日志和使用者单价估算，不是官方账单或当前并发会话列表。

本版应用 1,883,952 字节；写入哈希与独立读回通过，15 项设备串口检查通过。
本版实体屏幕未重新目视验收；截图为离屏示例。

详细说明：https://github.com/mengqy2022/Esp32-touch/blob/main/dist/PC_SCREEN_FIRMWARE_CN.md
